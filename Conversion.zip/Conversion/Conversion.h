// latitude and longitude are multiplied by 1,000,000.
// (47.621300, -122.350900) is Seattle Center House.
#define LATITUDE_ORIGIN   47.621300
#define LONGITUDE_ORIGIN -122.350900
#define EARTH_RADIUS_MM 6371000000.

//Converts provided Longitude and Latitude to MM
boolean convertLatLonToMM(long latitude, long longitude) {
    long scaledOriginLat = LATITUDE_ORIGIN * 1000000;
    long scaledOriginLon = LONGITUDE_ORIGIN * 1000000;
    
    double dLat = (latitude) * (PI / 180.0) - (scaledOriginLat) * (PI / 180.0);
    double dLon = latitude * (PI / 180.0) - scaledOriginLon * (PI / 180.0);
    
    Serial.println("dLat = " + String(dLat) + " dLon = " + String(dLon));
    double soln = sin(dLat / 2) * cos(dLat / 2) + cos(scaledOriginLat * PI / 180) * cos(latitude * PI / 180) * sin(dLon / 2) * sin(dLon / 2);
    double ans = 2 * atan2(sqrt(soln), sqrt(1 - soln));
    double finalAns = EARTH_RADIUS_MM * ans;
    return true;
}
